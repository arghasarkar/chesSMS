A Pen created at CodePen.io. You can find this one at http://codepen.io/DaNinjaKidy/pen/yadOyp.

 Connect four is two player game. You can play with pc this js version of game. Made with native javascript on codepen.